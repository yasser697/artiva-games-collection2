-keepclassmembers class com.artiva.games.MainActivity$AndroidBridge {
   @android.webkit.JavascriptInterface <methods>;
}
